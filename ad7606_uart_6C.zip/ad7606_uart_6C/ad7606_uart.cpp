/****************************************************************************
 * @file ad7606_uart.cpp
 *
 * @brief PX4 driver for receiving AD7606 ADC converted data via UART
 *        from an STM32 MCU on Pixhawk 6C, with single header synchronization.
 *
 ****************************************************************************/

#include <px4_platform_common/module.h>
#include <px4_platform_common/px4_config.h>
#include <px4_platform_common/log.h>
#include <px4_platform_common/posix.h>
#include <px4_platform_common/tasks.h>
#include <px4_platform_common/getopt.h>
#include <drivers/drv_hrt.h>
#include <termios.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <uORB/uORB.h>
#include <uORB/Publication.hpp>
#include <uORB/topics/ad7606_data.h>

// ---------------------------------------------------------------------------
// Utility helpers
// ---------------------------------------------------------------------------
static inline uint16_t u16(const uint8_t *b)
{
	return (uint16_t(b[0]) << 8) | b[1];
}

static inline uint32_t u32(const uint8_t *b)
{
	return (uint32_t(b[0]) << 24) |
	       (uint32_t(b[1]) << 16) |
	       (uint32_t(b[2]) << 8)  |
	        uint32_t(b[3]);
}

#define DEFAULT_UART_DEVICE "/dev/ttyS1"  
#define FRAME_SIZE 23
#define HEADER_0 '$'
#define HEADER_1 'M'
#define HEADER_2 'C'

extern "C" __EXPORT int ad7606_uart_main(int argc, char *argv[]);

class AD7606_UART
{
public:
	explicit AD7606_UART(const char *device_path);
	~AD7606_UART();

	bool init();
	void run();
	void stop();

private:
	int _fd{-1};
	const char *_device_path{nullptr};
	volatile bool _should_exit{false};

	uORB::Publication<ad7606_data_s> _pub{ORB_ID(ad7606_data)};
};

// ---------------------------------------------------------------------------
// Constructor / Destructor
// ---------------------------------------------------------------------------

AD7606_UART::AD7606_UART(const char *device_path) : _device_path(device_path) {}

AD7606_UART::~AD7606_UART()
{
	if (_fd >= 0) {
		::close(_fd);
		_fd = -1;
	}
}

// ---------------------------------------------------------------------------
// UART Initialization
// ---------------------------------------------------------------------------

bool AD7606_UART::init()
{
	_fd = ::open(_device_path, O_RDONLY | O_NOCTTY | O_NONBLOCK);

	if (_fd < 0) {
		PX4_ERR("Failed to open UART device: %s", _device_path);
		return false;
	}

	struct termios config;

	if (tcgetattr(_fd, &config) != 0) {
		PX4_ERR("tcgetattr failed");
		::close(_fd);
		_fd = -1;
		return false;
	}

	cfsetispeed(&config, B115200);
	cfsetospeed(&config, B115200);

	config.c_cflag &= ~(PARENB | CSTOPB | CSIZE | CRTSCTS);
	config.c_cflag |= (CS8 | CREAD | CLOCAL);
	config.c_iflag = IGNPAR;
	config.c_oflag = 0;
	config.c_lflag = 0;

	tcflush(_fd, TCIFLUSH);

	if (tcsetattr(_fd, TCSANOW, &config) != 0) {
		PX4_ERR("tcsetattr failed");
		::close(_fd);
		_fd = -1;
		return false;
	}

	PX4_INFO("AD7606 UART initialized on %s @115200 baud", _device_path);
	return true;
}

// ---------------------------------------------------------------------------
// Run Loop with Single-Byte Header Synchronization
// ---------------------------------------------------------------------------
bool first_frame_logged = false;

void AD7606_UART::run()
{
	uint8_t byte;
	uint8_t frame[FRAME_SIZE]{};
	int index = 0;

	while (!_should_exit) {

		if (read(_fd, &byte, 1) == 1) {

			// ---------------- HEADER SYNC ----------------
			if (index == 0 && byte != HEADER_0) continue;
			if (index == 1 && byte != HEADER_1) { index = 0; continue; }
			if (index == 2 && byte != HEADER_2) { index = 0; continue; }

			frame[index++] = byte;

			// ---------------- FRAME COMPLETE ----------------
			if (index == FRAME_SIZE) {

				// ---------- PARSE DATA ----------
				ad7606_data_s msg{};
				msg.timestamp = hrt_absolute_time();

				msg.ts           = u32(&frame[3]);
				msg.elev_port    = u16(&frame[7]);
				msg.elev_stbd    = u16(&frame[9]);
				msg.flap_port    = u16(&frame[11]);
				msg.flap_stbd    = u16(&frame[13]);
				msg.rudder_port  = u16(&frame[15]);
				msg.rudder_stbd  = u16(&frame[17]);
				msg.strain_port  = u16(&frame[19]);
				msg.strain_stbd  = u16(&frame[21]);

				_pub.publish(msg);

				static bool first = true;
				if (first) {
					PX4_INFO("[AD7606_UART] Frame sync OK, publishing decoded data");
					first = false;
				}

				// ---------- RESET FOR NEXT FRAME ----------
				index = 0;
			}
		}

		px4_usleep(1000);
	}
}

void AD7606_UART::stop()
{
	_should_exit = true;
}

// ---------------------------------------------------------------------------
// Module Task Management
// ---------------------------------------------------------------------------

namespace ad7606_uart_module
{
	static bool task_running = false;
	static int task_id = -1;
	static AD7606_UART *driver = nullptr;

	static int task_main(int argc, char *argv[])
	{
		const char *device_path = DEFAULT_UART_DEVICE;

		int ch;
		while ((ch = getopt(argc, argv, "d:")) != EOF) {
			switch (ch) {
			case 'd':
				device_path = optarg;
				break;
			default:
				PX4_WARN("Usage: ad7606_uart start [-d <device_path>]");
				return -1;
			}
		}

		driver = new AD7606_UART(device_path);

		if (!driver || !driver->init()) {
			PX4_ERR("Driver init failed");
			delete driver;
			driver = nullptr;
			return -1;
		}

		task_running = true;
		driver->run();

		delete driver;
		driver = nullptr;
		task_running = false;
		return 0;
	}
}

// ---------------------------------------------------------------------------
// CLI Interface
// ---------------------------------------------------------------------------

int ad7606_uart_main(int argc, char *argv[])
{
	using namespace ad7606_uart_module;

	if (argc < 2) {
		PX4_INFO("Usage: ad7606_uart {start|stop|status} [-d <device_path>]");
		return -1;
	}

	if (!strcmp(argv[1], "start")) {
		if (task_running) {
			PX4_WARN("Already running");
			return 0;
		}

		task_id = px4_task_spawn_cmd(
			"ad7606_uart",
			SCHED_DEFAULT,
			SCHED_PRIORITY_SLOW_DRIVER,
			1800,
			(px4_main_t)&task_main,
			argv);

		if (task_id < 0) {
			PX4_ERR("Task start failed");
			return -1;
		}
		return 0;
	}

	if (!strcmp(argv[1], "stop")) {
		if (!task_running || !driver) {
			PX4_WARN("Not running");
			return 0;
		}
		driver->stop();
		return 0;
	}

	if (!strcmp(argv[1], "status")) {
		PX4_INFO("AD7606 UART is %s", task_running ? "running" : "not running");
		return 0;
	}

	PX4_WARN("Unrecognized command");
	return -1;
}

